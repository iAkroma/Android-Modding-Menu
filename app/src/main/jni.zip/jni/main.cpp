#include <pthread.h>
#include <jni.h>
#include <Includes/Utils.h>
#include <Substrate/SubstrateHook.h>
#include "KittyMemory/MemoryPatch.h"
#include <Icon.h>
#include <Chams.h>
#include "Color.h"
#include "Vector3.h"

extern "C" {

char* libName = "libil2cpp.so";
bool mbt, bz, nc, nr, ns, bs, fr, nr2, ns2, nospawn = false;

bool wireframe, outline, glow, whfix = false;
int wirer, wireg, wireb = 1;
int outr, outg, outb    = 1;
int glowr, glowg, glowb = 1;
int wirew, outw, gloww  = 1;
bool slw = false;
bool fov = false;
int fov_value = 1;
bool bhop, jumphack, wallclimb = false;

bool smoke = false;
int smoker, smokeg, smokeb = 1;
int smokea = 255;

bool deathf, killf = false;
std::string deathText = "Умер,бля";
std::string killText  = "tw 73";

bool kar, butt, m9, giveall, skinsall, attach = false;
bool schg = false;
int schid, schw = 0;
int schs = 0;
bool logg = false;
std::string logText = "Null";

bool wgive, bsd = false;
int givesid = 0;
int givewid = 0;

bool spam, gomap, gamemode = false;
std::string spamText = "❤️ t.me/insineteam_modders ❤️";
std::string mapName = "bloxpoligon";

struct My_Patches {MemoryPatch Noclip, MoveBT, BuyZone, Attach, NoSpawn;} hexPatches;

JNIEXPORT jstring JNICALL
Java_il2cpp_Main_getTitle(JNIEnv *env, jobject activityObject) {
	return env->NewStringUTF("InsineTeam Free | PATCH 1.6");
}

JNIEnv *enve; 
void Toast(JNIEnv *env, const char *text, int length) { 
 jstring jstr = env->NewStringUTF(text); 
 jclass toast = env->FindClass(("android/widget/Toast")); 
 jmethodID methodMakeText =env->GetStaticMethodID(toast,("makeText"),("(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;")); 
 jclass activityThread = env->FindClass("android/app/ActivityThread"); 
 jmethodID currentActivityThread = env->GetStaticMethodID(activityThread, "currentActivityThread", "()Landroid/app/ActivityThread;"); 
 jobject at = env->CallStaticObjectMethod(activityThread, currentActivityThread); 
 jmethodID getApplication = env->GetMethodID(activityThread, "getApplication", "()Landroid/app/Application;"); 
 jobject context = env->CallObjectMethod(at, getApplication); 
 jobject toastobj = env->CallStaticObjectMethod(toast, methodMakeText,context, jstr, length); 
 jmethodID methodShow = env->GetMethodID(toast, ("show"), ("()V")); 
 env->CallVoidMethod(toastobj, methodShow); 
}

JNIEXPORT jobjectArray  JNICALL
Java_il2cpp_Main_getFeatures(JNIEnv *env, jobject activityObject) { jobjectArray ret;
    // PAGE_Name_Icon_Lines
	// SWITCH_Page_Line_Feature_Text_Size
	// SLIDER_Page_Line_Feature_Text_Min_Max_Current_Size
	// BUTTON_Page_Line_Feature_Text_Size
	// INPUT_Page_Line_Feature_Text_Size
	// TITLE_Page_Line_Text_Size
	
    const char *features[] = {
            "PAGE_Player_player.png_2", // 0
			"PAGE_Visuals_visuals.png_2", // 1
			"PAGE_Skinchanger_cfg.png_1", // 2
			
			/* >>>> 0 <<<< */
			"TITLE_0_0_Movement_13", // Movement
			"SWITCH_0_0_1_Noclip (Kicked)_13",
			"SWITCH_0_0_2_Move before timer_11",
			"SWITCH_0_0_3_Buyzone radius_13",
			"SWITCH_0_0_15_No return spawn_12",
			"BUTTON_0_0_555_BunnyHop_13",
			"BUTTON_0_0_556_JumpHack (+NRS)_12",
			"TITLE_0_0_Weapon_13", // Weapon
			"BUTTON_0_0_666_Firerate_13",
			"BUTTON_0_0_4_Recoil control_13",
			"BUTTON_0_0_5_Spread control_13",
			"SWITCH_0_0_1200_No recoil (lobby)_13",
			"SWITCH_0_0_1201_No spread (lobby)_13",
			"SWITCH_0_0_12_Infinity ammo (no dmg)_9",
			"BUTTON_0_0_1231_Set ammo_13",
			"TITLE_0_0_Camera_13", // Camera
			"SWITCH_0_0_21_Fov_13",
			"SLIDER_0_0_22_Fov value_0_100_0_11",
			
			"TITLE_2_0_Skinchanger_13",
			"SWITCH_2_0_6_Prime + Karambit_11",
			"SWITCH_2_0_7_Butterfly_13",
			"SWITCH_2_0_8_M9 Bayonet_13",
			"TITLE_2_0_Inventory changer_13",
			"BUTTON_2_0_9_Give all weapons_12",
			"BUTTON_2_0_1001_Give all skins (polygon)_9",
			"SWITCH_2_0_10_Unlock attachment_11",
			"TITLE_2_0_Skinchanger Visual_13",
			"SLIDER_2_0_4000_Slot ID_0_3_0_13",
			"INPUT_2_0_4001_Weapon ID_12",
			"INPUT_2_0_4002_Skin ID_12",
			"BUTTON_2_0_4003_Give weapon_13",
			"TITLE_2_0_Visual knifes_13",
			"TITLE_2_0_Butterfly_13",
			"BUTTON_2_0_16001_Acid_13", // 77
			"BUTTON_2_0_16002_Neonkiller_13", // 78
			"BUTTON_2_0_16003_Prototype_13", // 79
			"BUTTON_2_0_16004_Technomage_13", // 80
			"TITLE_2_0_Flip knife_13",
			"BUTTON_2_0_17001_Protector_13", // 152
			"BUTTON_2_0_17002_Glow_13", // 153
			"BUTTON_2_0_17003_Rainbow_13", // 154
			"TITLE_2_0_Karambit_13",
			"BUTTON_2_0_18001_Leaves_13", // 56
			"BUTTON_2_0_18002_Snowball_13", // 95
			"BUTTON_2_0_18003_Witch_13", // 134
			"TITLE_2_0_M9 Bayonet_13",
			"BUTTON_2_0_19001_One_13", // 114
			"BUTTON_2_0_19002_Sport_13", // 115
			"TITLE_2_0_Bowie_13",
			"BUTTON_2_0_20001_Zero_13", // 182
			"TITLE_2_0_Gut knife_13",
			"BUTTON_2_0_21001_Night spider_13", // 129
			"BUTTON_2_0_21002_Crystal_13", // 168
			
			"TITLE_0_1_Map Hack_13",
			"INPUT_0_1_401_Map name_13",
			"BUTTON_0_1_402_Go to map_13",
			"SWITCH_0_1_403_Gamemode hack_12",
			
			"TITLE_0_1_Chat Hack_13",
			"INPUT_0_1_451_Spam text_13",
			"BUTTON_0_1_452_Send to chat_13",
			"SWITCH_0_1_453_Spam chat_12",
			"BUTTON_0_1_454_Insine text_13",
			
			"TITLE_0_1_Death_13",
			"INPUT_0_1_461_Death text_13",
			"SWITCH_0_1_462_Death message_12",
			"TITLE_0_1_Console_13",
			"INPUT_0_1_463_Command_13",
			"BUTTON_0_1_464_SEND_12",
			
			/* >>>> 1 <<<< */
			
			"TITLE_1_0_Wireframe_13",
			"SWITCH_1_0_101_Enable_12",
			"TITLE_1_0_Color_10",
			"SLIDER_1_0_102_Red_1_255_1_10",
			"SLIDER_1_0_103_Green_1_255_1_10",
			"SLIDER_1_0_104_Blue_1_255_1_10",
			"TITLE_1_0_Line_10",
			"SLIDER_1_0_105_Width_1_50_1_10",
			
			"TITLE_1_0_Outline_13",
			"SWITCH_1_0_111_Enable_12",
			"TITLE_1_0_Color_10",
			"SLIDER_1_0_112_Red_1_255_1_10",
			"SLIDER_1_0_113_Green_1_255_1_10",
			"SLIDER_1_0_114_Blue_1_255_1_10",
			"TITLE_1_0_Line_10",
			"SLIDER_1_0_115_Width_1_50_1_10",
			
			"TITLE_1_0_Glow_13",
			"SWITCH_1_0_121_Enable_12",
			"TITLE_1_0_Color_10",
			"SLIDER_1_0_122_Red_1_255_1_10",
			"SLIDER_1_0_123_Green_1_255_1_10",
			"SLIDER_1_0_124_Blue_1_255_1_10",
			"TITLE_1_0_Line_10",
			"SLIDER_1_0_125_Width_1_50_1_10",
			
			"TITLE_1_1_Smoke setting_12",
			"SWITCH_1_1_701_Color_11",
			"TITLE_1_1_Color_13",
			"SLIDER_1_1_702_Red_1_255_1_10",
			"SLIDER_1_1_703_Green_1_255_1_10",
			"SLIDER_1_1_704_Blue_1_255_1_10",
			"TITLE_1_1_Wallhack fix_12",
			"SWITCH_1_1_921_Prime & Bundle skins fix_9",
			
    };

    int Total_Feature = (sizeof features /
                         sizeof features[0]); //Now you dont have to manually update the number everytime;

    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass("java/lang/String"),
                                             env->NewStringUTF(""));
    int i;
    for (i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));
    return (ret);
} 

void addLog(std::string text) {
	logg = true;
	logText = text;
}

void giveSkin(int w, int s) {
	wgive = true;
	givewid = w;
	givesid = s;
}

void hexChange(bool &var, MemoryPatch &patch) {
	var = !var;
	if (var) {
		patch.Modify();
	} else {
		patch.Restore();
	}
}

std::string to_string(int param)
{
    std::string str = "";
    for(str = ""; param ; param /= 10)
        str += (char)('0' + param % 10);
    reverse(str.begin(), str.end());
	if (str == "") str = "0";
    return str;
}

void updateChams() {
	SetWallhack(false);
	SetWireframe(wireframe);
	SetGlow(glow);
	SetOutline(outline);
	SetOR(outr);SetOG(outg);SetOB(outb);
	SetGR(glowr);SetGG(glowg);SetGB(glowb);
	SetR(wirer);SetG(wireg);SetB(wireb);
	SetWireframeWidth(wirew);SetOutlineWidth(outw);SetGlowWidth(gloww);
}

std::string jstring2string(JNIEnv *env, jstring jStr) {
    if (!jStr)
        return "";

    const jclass stringClass = env->GetObjectClass(jStr);
    const jmethodID getBytes = env->GetMethodID(stringClass, "getBytes", "(Ljava/lang/String;)[B");
    const jbyteArray stringJbytes = (jbyteArray) env->CallObjectMethod(jStr, getBytes, env->NewStringUTF("UTF-8"));

    size_t length = (size_t) env->GetArrayLength(stringJbytes);
    jbyte* pBytes = env->GetByteArrayElements(stringJbytes, NULL);

    std::string ret = std::string((char *)pBytes, length);
    env->ReleaseByteArrayElements(stringJbytes, pBytes, JNI_ABORT);

    env->DeleteLocalRef(stringJbytes);
    env->DeleteLocalRef(stringClass);
    return ret;
}

JNIEXPORT void JNICALL
Java_il2cpp_Main_OnChange(JNIEnv *env, jobject activityObject, jint feature, jint value, jstring strv) {jobjectArray ret;
	
	std::string str_value = jstring2string(env, strv);
	
	switch (feature) {
		
		case 1231:
			bsd = true;
			addLog("Seted");
			break;
		
		// Skinchanger
		case 16001:
			giveSkin(69, 77);
			break;
		case 16002:
			giveSkin(69, 78);
			break;
		case 16003:
			giveSkin(69, 79);
			break;
		case 16004:
			giveSkin(69, 80);
			break;
		
		case 17001:
			giveSkin(76, 152);
			break;
		case 17002:
			giveSkin(76, 153);
			break;
		case 17003:
			giveSkin(76, 154);
			break;
		
		case 18001:
			giveSkin(3, 56);
			break;
		case 18002:
			giveSkin(3, 95);
			break;
		case 18003:
			giveSkin(3, 134);
			break;
		
		case 19001:
			giveSkin(72, 114);
			break;
		case 19002:
			giveSkin(72, 115);
			break;
		
		case 20001:
			giveSkin(73, 182);
			break;
		
		case 21001:
			giveSkin(68, 129);
			break;
		case 21002:
			giveSkin(68, 168);
			break;
		
		case 1:
			hexChange(nc, hexPatches.Noclip);
			break;
		case 2:
			hexChange(mbt, hexPatches.MoveBT);
			break;
		case 3:
			hexChange(bz, hexPatches.BuyZone);
			break;
		case 4:
			nr = true;
			break;
		case 5:
			ns = true;
			break;
		case 12:
			bs = !bs;
			break;
		case 921:
			whfix = !whfix;
			break;
		case 15:
			hexChange(nospawn, hexPatches.NoSpawn);
			break;
		case 666:
			fr = true;
			break;
		case 555:
			bhop = true;
			break;
		case 556:
			jumphack = true;
			break;
		case 1001:
			skinsall = true;
			break;
			
		case 401:
			mapName = str_value;
			break;
		case 451:
			spamText = str_value;
			break;
		
		case 402:
			gomap = true;
			break;
		case 403:
			gamemode = !gamemode;
			break;
		
		case 452:
			addLog(spamText);
			break;
		case 453:
			spam = !spam;
			break;
		case 454:
			spamText = "❤️ t.me/insineteam_modders ❤️";
			break;
		case 461:
			deathText = str_value;
			break;
		case 462:
			deathf = !deathf;
			break;
		case 463:
			killText = str_value;
			break;
		case 464:
			killf = !killf;
			break;
		
		case 4000:
			schs = value;
			break;
		case 4001:
			schw = std::atoi(str_value.c_str());
			break;
		case 4002:
			schid = std::atoi(str_value.c_str());
			break;
		case 4003:
			schg = true;
			break;
		
		case 6:
			kar = !kar;
			break;
		case 7:
			butt = !butt;
			break;
		case 8:
			m9 = !m9;
			break;
		case 9:
			giveall = true;
			break;
		case 10:
			hexChange(attach, hexPatches.Attach);
			break;
		
		case 21:
			fov = !fov;
			break;
		case 22:
			fov_value = value;
			break;
			
		case 101:
			wireframe = !wireframe;
			break;
		case 111:
			outline = !outline;
			break;
		case 121:
			glow = !glow;
			break;
		
		case 102:
			wirer = value;
			break;
		case 103:
			wireg = value;
			break;
		case 104:
			wireb = value;
			break;
		case 105:
			wirew = value;
			break;
		
		case 112:
			outr = value;
			break;
		case 113:
			outg = value;
			break;
		case 114:
			outb = value;
			break;
		case 115:
			outw = value;
			break;
		
		case 1200:
			nr2 = !nr2;
			break;
		case 1201:
			ns2 = !ns2;
			break;
		
		case 122:
			glowr = value;
			break;
		case 123:
			glowg = value;
			break;
		case 124:
			glowb = value;
			break;
		case 125:
			gloww = value;
			break;
			
		case 701:
			smoke = !smoke;
			break;
		case 702:
			smoker = value;
			break;
		case 703:
			smokeg = value;
			break;
		case 704:
			smokeb = value;
			break;
	}
	updateChams();
}

// ***** C *****
}

// ---------- Hooking ---------- //

// BPM 1.20F3
namespace Offsets{
	enum Ofssets {
		Noclip        = 0x123C5B8,
		MoveBT        = 0x12AD1D0,
		BuyZone       = 0x12ABA54,
		SetFov        = 0x12BDAE0,
		Update1       = 0x4EE490,
		ExitMenu      = 0x4EF9AC,
		LoadMap       = 0x4EF40C,
		SpamChat      = 0x12A83D0,
		ChatUpdate    = 0x12A762C,
		PlayerUpdate  = 0x41DFB0,
		StartServer   = 0x12A6FEC,
		UnlockAttach  = 0x5E597C,
		NoRecoil      = 0x3C9518,
		NoSpread      = 0x3C9590,
		BulletSpread  = 0x3C9608,
		NoSpawn       = 0x12BDC40,
		SmokeColor    = 0xC20008
	};
}

using namespace std;std::string utf16le_to_utf8(const std::u16string &u16str) {    if (u16str.empty()) { return std::string(); }    const char16_t *p = u16str.data();    std::u16string::size_type len = u16str.length();    if (p[0] == 0xFEFF) {        p += 1;        len -= 1;    }    std::string u8str;    u8str.reserve(len * 3);    char16_t u16char;    for (std::u16string::size_type i = 0; i < len; ++i) {        u16char = p[i];        if (u16char < 0x0080) {            u8str.push_back((char) (u16char & 0x00FF));            continue;        }        if (u16char >= 0x0080 && u16char <= 0x07FF) {            u8str.push_back((char) (((u16char >> 6) & 0x1F) | 0xC0));            u8str.push_back((char) ((u16char & 0x3F) | 0x80));            continue;        }        if (u16char >= 0xD800 && u16char <= 0xDBFF) {            uint32_t highSur = u16char;            uint32_t lowSur = p[++i];            uint32_t codePoint = highSur - 0xD800;            codePoint <<= 10;            codePoint |= lowSur - 0xDC00;            codePoint += 0x10000;            u8str.push_back((char) ((codePoint >> 18) | 0xF0));            u8str.push_back((char) (((codePoint >> 12) & 0x3F) | 0x80));            u8str.push_back((char) (((codePoint >> 06) & 0x3F) | 0x80));            u8str.push_back((char) ((codePoint & 0x3F) | 0x80));            continue;        }        {            u8str.push_back((char) (((u16char >> 12) & 0x0F) | 0xE0));            u8str.push_back((char) (((u16char >> 6) & 0x3F) | 0x80));            u8str.push_back((char) ((u16char & 0x3F) | 0x80));            continue;        }    }    return u8str;}typedef struct _monoString {    void *klass;    void *monitor;    int length;    const char *toChars(){        u16string ss((char16_t *) getChars(), 0, getLength());        string str = utf16le_to_utf8(ss);        return str.c_str();    }    char chars[0];    char *getChars() {        return chars;    }    int getLength() {        return length;    }    std::string get_string() {                return std::string(toChars());    }} monoString;monoString *CreateMonoString(const char *str) {    monoString *(*String_CreateString)(void *instance, const char *str) = (monoString *(*)(void *, const char *))getAbsoluteAddress("libil2cpp.so", 0xBF68CC);     return String_CreateString(NULL, str);}

void (*addItem) (void* instance, int type, int wid, int uid, int menu, monoString* sign, int cat);
void (*addPrime) (void* instance);
void (*sendChat) (void* instance, int t, monoString* text);
void (*loadMap) (void* instance, monoString* mapnames);
void (*sendCmd) (void* instance, monoString* cmds);
void (*addWpn) (int slot, int itemid, int uid, int skinid, int mz, int fz, int mg, int sc, int si);
void (*setAmmoWpn) (void* instance, int bqq, int bqq2);
void (*selectSlot) (void* instance, int slt, bool bbbb, bool bbb2);

void* (*old_addDefault) (void* instance);
void addDefault (void* instance) {
	if (instance) {
		if (kar) {
			kar = false;
			addPrime(instance);
		}
		if (skinsall) {
			skinsall = false;
			for (int id = 1; id < 1500; id++) addItem(instance, 2, id, 777, 1, CreateMonoString("_"), 0);
		}
		if (butt) {
			butt = false;
			addItem(instance, 0, 69, 777, 0, CreateMonoString("_"), 0);
		}
		if (m9) {
			m9 = false;
			addItem(instance, 0, 72, 777, 0, CreateMonoString("_"), 0);
		}
		if (giveall) {
			giveall = false;
			for (int id = 0; id <= 95; id++) {
				if (id != 3 && id != 69 && id != 72) addItem(instance, 0, id, 777, 0, CreateMonoString("_"), 0);
			}
		}
	}
	old_addDefault(instance);
}

void (*old_SmokeColor) (Color c);
void SmokeColor (Color c) {
	if (smoke) {
		c = Color(smoker / 255.0f, smokeb / 255.0f, smokeg / 255.0f);
	}
	old_SmokeColor(c);
}

float (*old_RecoilHack) (void *instance);
float RecoilHack (void *instance) {
	if (instance && nr2) {
		return -0.9;
	}
	return old_RecoilHack(instance);
}

float (*old_SpreadHack) (void *instance);
float SpreadHack (void *instance) {
	if (instance && ns2) {
		return -0.9;
	}
	return old_SpreadHack(instance);
}

void (*old_fovset) (float fovv,  float speed); 
void fovset(float fovv, float speed) {
	if (fov)
		old_fovset(fov_value, 120);
	else
		old_fovset(fovv, speed);
}

int scop;

void (*old_f1upd) (...);
void f1upd (void *instance) {
	if (instance) {
		void *weapon = *(void* *) ((uint64_t) instance + 0x10);
		if (bsd) {
			bsd = false;
			//scop = *(int *) ((uint64_t) weapon + 0x9C);
			*(int *) ((uint64_t) weapon + 0x200) = 30;
		}
		if (slw) {
			slw = false;
			selectSlot(instance, 2, false, false);
		}
		if (fr) {
			fr = false;
			//Vector3 vect = *(Vector3 *) ((uint64_t) weapon + 0x154);
			//*(Vector3 *) ((uint64_t) weapon + 0x154) = Vector3(vect.x, vect.y, vect.z+20);
			*(float *) ((uint64_t) weapon + 0xD0) = 0.01f;
		}
		if (nr) {
			nr = false;
			*(float *) ((uint64_t) weapon + 0xF4) = 990.00f;
			*(float *) ((uint64_t) weapon + 0xF8) = 0.00f;
			*(float *) ((uint64_t) weapon + 0x104) = 0.00f;
		}
		if (ns) {
			ns = false;
			*(float *) ((uint64_t) weapon + 0x108) = 0.00f;
		}
	}
	old_f1upd(instance);
}

void (*old_f2) (...);
void f2 (void *instance) {
	if (bhop || jumphack || wallclimb) {
		void *control = *(void* *) ((uint64_t) instance + 0xC);
		if (bhop) {
			bhop = false;
			*(float *) ((uint64_t) control + 0x34) = 2.0f;
		}
		if (jumphack) {
			jumphack = false;
			*(float *) ((uint64_t) control + 0x30) = 15.0f;
		}
	}
	old_f2(instance);
}

void (*old_f3) (...);
void f3 (void *instance) {
	if (instance && wgive) {
		wgive = false;
		slw = true;
		addWpn(2, givewid, 777, givesid, 0, 0, 0, 0, 0);
	}
	if (instance && schg) {
		schg = false;
		addWpn(schs, schw, 777, schid, 0, 0, 0, 0, 0);
	}
	if (instance && logg) {
		logg = false;
		sendChat(instance, 0, CreateMonoString(logText.c_str()));
	}
	if (instance && spam) {
		sendChat(instance, 0, CreateMonoString(spamText.c_str()));
	}
	old_f3(instance);
}

void (*old_startserv) (void *instance, void* ps);
void startserv (void *instance, void* ps) {
	if (instance) {
		if (gamemode) {
			*(monoString* *) ((uint64_t) ps + 0xC)  = CreateMonoString(mapName.c_str());
			*(monoString* *) ((uint64_t) ps + 0x14) = CreateMonoString(mapName.c_str());
			*(monoString* *) ((uint64_t) ps + 0x1C)  = CreateMonoString(mapName.c_str());
			*(monoString* *) ((uint64_t) ps + 0x24) = CreateMonoString(mapName.c_str());
			*(monoString* *) ((uint64_t) ps + 0x2C)  = CreateMonoString(mapName.c_str());
		}
	}
	old_startserv(instance, ps);
}

void (*old_update1) (void* instance);
void update1 (void* instance) {
	if (instance) {
		if (gomap) {
			gomap = false;
			loadMap(instance, CreateMonoString(mapName.c_str()));
		}
	}
	
	old_update1(instance);
}

void (*old_Death) (...);
void Death(void *instance, void *p, int id, int vid) {
	if (instance && deathf) {
		addLog(deathText);
	}
	old_Death(instance, p, id, vid);
}

void (*old_Upd) (...);
void Upd (void* instance) {
	if (killf) {
		killf = false;
		sendCmd(instance, CreateMonoString(killText.c_str()));
	}
	old_Upd(instance);
}

void (*old_setAmmo) (...);
void setAmmo(void *instance, int clip, int back) {
	if (bs) {
		old_setAmmo(instance, 9999999, 99999999);
	} else {
		old_setAmmo(instance, clip, back);
	}
}

void (*old_loadSkin) (...);
void loadSkin(void *instance, int id, monoString* playername, int team, int gid, int avatar, int skin, int prime) {
	if (skin % 2 == 0) {
		if (whfix) skin = 0;
	} else {
		if (whfix) skin = 1;
	}
	old_loadSkin(instance, id, playername, team, gid, avatar, skin, prime);
}

void (*old_up) (...);
void up (void *instance, int id, int team, monoString* text) {
	if (text->get_string() == "/check") {
		addLog("Лучшие читы @insineteam_modders");
	} else {
		old_up(instance, id, team, text);
	}
}

void *hack_thread(void *) {
    
    ProcMap il2cppMap;
    do {
        il2cppMap = KittyMemory::getLibraryMap(libName);
        sleep(1);
    } while (!isLibraryLoaded(libName) && mlovinit());
		sleep(2);
	
	setShader("unity_SHC");
	LogShaders();
	Wallhack();
	updateChams();
	
    // ---------- Hook ---------- //
    
	MSHookFunction((void *) getAbsoluteAddress(libName, 0x40C5D0), (void *) loadSkin, (void **) &old_loadSkin);
	
	MSHookFunction((void *) getAbsoluteAddress(libName, 0x3B5438), (void *) f1upd, (void **) &old_f1upd);
	MSHookFunction((void *) getAbsoluteAddress(libName, 0x58E0A8), (void *) f2, (void **) &old_f2);
	MSHookFunction((void *) getAbsoluteAddress(libName, 0x12A762C), (void *) f3, (void **) &old_f3);
	MSHookFunction((void *) getAbsoluteAddress(libName, 0x12BBF6C), (void *) Upd, (void **) &old_Upd);
	
	MSHookFunction((void *) getAbsoluteAddress(libName, 0x41A038), (void *) Death, (void **) &old_Death);
	
	MSHookFunction((void *) getAbsoluteAddress(libName, 0x6149E4), (void *) up, (void **) &old_up);
	
	hexPatches.Noclip = MemoryPatch::createWithHex("libil2cpp.so", Offsets::Noclip, "00 00 A0 E3 1E FF 2F E1");
	hexPatches.MoveBT = MemoryPatch::createWithHex("libil2cpp.so", Offsets::MoveBT, "00 00 A0 E3 1E FF 2F E1");
	hexPatches.BuyZone = MemoryPatch::createWithHex("libil2cpp.so", Offsets::BuyZone, "00 00 A0 E3 1E FF 2F E1");
	hexPatches.Attach = MemoryPatch::createWithHex("libil2cpp.so", Offsets::UnlockAttach, "00 00 A0 E3 1E FF 2F E1");
	hexPatches.NoSpawn = MemoryPatch::createWithHex("libil2cpp.so", Offsets::NoSpawn, "1EFF2FE11EFF2FE1");
	
	MSHookFunction((void *) getAbsoluteAddress(libName, 0x4A0714), (void *) setAmmo, (void **) &old_setAmmo);
	MSHookFunction((void *) getAbsoluteAddress(libName, Offsets::NoRecoil), (void *) RecoilHack, (void **) &old_RecoilHack);	
	MSHookFunction((void *) getAbsoluteAddress(libName, Offsets::NoSpread), (void *) SpreadHack, (void **) &old_SpreadHack);	
	MSHookFunction((void *) getAbsoluteAddress(libName, Offsets::SetFov), (void *) fovset, (void **) &old_fovset);	
	MSHookFunction((void *) getAbsoluteAddress(libName, Offsets::Update1), (void *) update1, (void **) &old_update1);	
	
	MSHookFunction((void *) getAbsoluteAddress(libName, Offsets::SmokeColor), (void *) SmokeColor, (void **) &old_SmokeColor);	
	
	MSHookFunction((void *) getAbsoluteAddress(libName, 0x4D206C), (void *) addDefault, (void **) &old_addDefault);
	addItem = (void (*)(void*, int, int, int, int, monoString*, int)) getAbsoluteAddress("libil2cpp.so", 0x4D280C);
	addPrime = (void (*)(void*)) getAbsoluteAddress("libil2cpp.so", 0x4D335C);
	sendChat = (void (*)(void*, int, monoString*)) getAbsoluteAddress("libil2cpp.so", 0x12A83D0);
	loadMap  = (void (*)(void*, monoString*)) getAbsoluteAddress("libil2cpp.so", Offsets::LoadMap);
	addWpn  = (void (*)(int, int, int, int, int, int, int, int, int)) getAbsoluteAddress("libil2cpp.so", 0x67B068);
	
	setAmmoWpn  = (void (*)(void*, int, int)) getAbsoluteAddress("libil2cpp.so", 0x12D1440);
	selectSlot  = (void (*)(void*, int, bool, bool)) getAbsoluteAddress("libil2cpp.so", 0x3BE438);
	sendCmd  = (void (*)(void*, monoString*)) getAbsoluteAddress("libil2cpp.so", 0x12BB7F4);
	
    return NULL;
}

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
	
	_JavaVM* publicJVM = vm; 
	publicJVM->GetEnv((void **) &globalEnv, JNI_VERSION_1_6); 
	enve = globalEnv;
	
	Toast(enve, "@InsineTeam_Modders", 1);
	
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);

    return JNI_VERSION_1_6;
}

JNIEXPORT void JNICALL
JNI_OnUnload(JavaVM *vm, void *reserved) {}
